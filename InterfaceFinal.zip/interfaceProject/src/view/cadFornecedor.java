package view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.ListSelectionModel;
import java.awt.SystemColor;
import java.awt.TextArea;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import java.awt.Font;

public class cadFornecedor extends JFrame {

	private JPanel contentPane;
	private JTextField txt_EndForn;
	private JTextField txt_ContatoForn;
	private JTextField txt_RSForn;
	private JTextField txt_NomeForn;
	private JTextField txt_CNPJForn;
	private JLabel lblFornecedor;
	private JLabel lblRS;
	private JLabel lblContato;
	private JLabel lblCNPJ;
	private JLabel lblDescri;
	private JMenuBar menuBar;
	private JMenu mnMenu;
	private JMenu mnAjuda;
	private JMenuItem mntmSobre;
	private JMenuItem mntmNovo;
	private JMenuItem mntmVoltar;
	private JTextField txtOK;
	private TextArea txtDescricao;
	private JScrollPane scrollz;
	private JTable table;
	private JPanel panel;
	private JLabel lblFornecedor_title;
	private JPanel panel_1;

	public static void main(String[] args) {
		try //design
		{
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) 
            {
                if ("Nimbus".equals(info.getName())) 
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
         } 
		catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) 
		{
            System.err.println(ex);        
        }
		EventQueue.invokeLater(new Runnable(){
			public void run() 
			{
				try 
				{
					cadFornecedor frame = new cadFornecedor();
					frame.setVisible(true);
				} 
				catch (Exception e) 
				{					
					e.printStackTrace();			
				}
			}
		});
	}
	public cadFornecedor() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 711, 928);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 712, 33);
		contentPane.add(menuBar);
		
		mnMenu = new JMenu("Menu |");
		menuBar.add(mnMenu);
		
		mntmNovo = new JMenuItem("Novo");
		mnMenu.add(mntmNovo);
		mntmNovo.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				txt_CNPJForn.setText("");
				txt_ContatoForn.setText("");
				txt_EndForn.setText("");
				txt_NomeForn.setText("");
				txt_RSForn.setText("");
				txtDescricao.setText(""); //esse nao esta funcionando :C
			}	
			
		});
		
		mntmVoltar = new JMenuItem("Voltar");
		mnMenu.add(mntmVoltar);
		mntmVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
			   principal p = new principal();
			   p.setVisible(true);
			   dispose();			   
			}
		});
		
		mnAjuda = new JMenu("Ajuda");
		menuBar.add(mnAjuda);
		
		mntmSobre = new JMenuItem("Sobre");		
		mnAjuda.add(mntmSobre);
		mntmSobre.addActionListener(new ActionListener() 
		{			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				sobre soulburn = new sobre();
				soulburn.setVisible(true);				
			}
		});
		
		
		JPanel grade1 = new JPanel();
		grade1.setBorder(new CompoundBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), null)); 
		grade1.setBounds(42, 111, 621, 418);
		contentPane.add(grade1);
		grade1.setLayout(null);
		
		JButton button = new JButton("Salvar");
		button.setBounds(312, 368, 120, 37);
		grade1.add(button);
		
		JButton button_1 = new JButton("Cancelar");
		button_1.setBounds(461, 368, 120, 37);
		grade1.add(button_1);
		
		txt_NomeForn = new JTextField();
		txt_NomeForn.setBounds(26, 50, 555, 24);
		grade1.add(txt_NomeForn);
		txt_NomeForn.setColumns(10);
		
		lblFornecedor = new JLabel("Nome do Fornecedor");
		lblFornecedor.setBounds(26, 33, 177, 16);
		grade1.add(lblFornecedor);
		
		lblRS = new JLabel("Raz\u00E3o Social");
		lblRS.setBounds(26, 87, 90, 16);
		grade1.add(lblRS);
		
		txt_RSForn = new JTextField();
		txt_RSForn.setBounds(26, 105, 555, 24);
		grade1.add(txt_RSForn);
		txt_RSForn.setColumns(10);
		
		JLabel lblEndereco = new JLabel("Endere\u00E7o");
		lblEndereco.setBounds(26, 142, 109, 16);
		grade1.add(lblEndereco);
		
		txt_EndForn = new JTextField();
		txt_EndForn.setBounds(26, 160, 555, 24);
		grade1.add(txt_EndForn);
		txt_EndForn.setColumns(10);
		
		lblCNPJ = new JLabel("CNPJ");
		lblCNPJ.setBounds(26, 197, 56, 16);
		grade1.add(lblCNPJ);
		
		txt_CNPJForn = new JTextField();
		txt_CNPJForn.setBounds(26, 219, 234, 24);
		grade1.add(txt_CNPJForn);
		txt_CNPJForn.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ev) {
				char c= ev.getKeyChar();
				if(!(Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE) || c==KeyEvent.VK_DELETE))
				{
					ev.consume(); 
				}
			}
		});
		txt_CNPJForn.setColumns(10);
		
		txt_ContatoForn = new JTextField();
		txt_ContatoForn.setBounds(347, 219, 234, 24);
		grade1.add(txt_ContatoForn);
		txt_ContatoForn.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
					char c= e.getKeyChar();
					if(!(Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE) || c==KeyEvent.VK_DELETE))
					{
						e.consume(); 
					}
			}
		});
		txt_ContatoForn.setColumns(10);
		
		lblContato = new JLabel("Contato");
		lblContato.setBounds(347, 197, 56, 16);
		grade1.add(lblContato);
		
		lblDescri = new JLabel("Descri\u00E7\u00E3o");
		lblDescri.setBounds(26, 256, 109, 16);
		grade1.add(lblDescri);
		
		txtDescricao = new TextArea();
		txtDescricao.setRows(10);
		txtDescricao.setBounds(26, 278, 554, 82);
		grade1.add(txtDescricao);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg) 
			{
				if (JOptionPane.showConfirmDialog(null, " Tem certeza que deseja cancelar? \nOs dados n�o ser�o salvos.", "Aten��o",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) 
				{
					  principal p = new principal();	
					  p.setVisible(true);
					  dispose();	
				} else 
				{
					  setVisible(true);						    
				}				
			
			}
		});
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent salvar) 
			{
				//CtrlFornecedor adicionar = new CtrlFornecedor(); FUN��O CONTROLE, TIRE DO COMENT�RIO PARA QUE POSSA SER IMPLEMENTADO
				//adicionar.inclui(conn, txt_CNPJForn, txt_RSForn, txt_NomeForn, txt_ContatoForn, txt_EndForn, txtDescricao);
				JOptionPane.showMessageDialog(null, " Dados cadastrados com sucesso! ", "Sucesso",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		
		JPanel grade2 = new JPanel();
		grade2.setLayout(null);
		grade2.setBorder(new CompoundBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(191, 205, 219), null), null));
		grade2.setBounds(42, 542, 621, 316);
		contentPane.add(grade2);
		
		JButton bttAlterar = new JButton("Alterar");
		bttAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				JOptionPane.showMessageDialog(null, " Dados alterados! ", "Altera��o ",JOptionPane.INFORMATION_MESSAGE);
			}
			
		});
		bttAlterar.setBounds(312, 266, 120, 37);
		grade2.add(bttAlterar);
		
		JButton bttRemover = new JButton("Remover");
		bttRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				JOptionPane.showMessageDialog(null, " Dados removidos! ", "Remo��o ",JOptionPane.INFORMATION_MESSAGE);				
			}
		});
		bttRemover.setBounds(456, 266, 120, 37);
		grade2.add(bttRemover);
		
		txtOK = new JTextField();
		txtOK.setColumns(10);
		txtOK.setBounds(23, 44, 243, 26);
		grade2.add(txtOK);
		
		JButton bttOK = new JButton("OK");
		bttOK.setBounds(278, 44, 49, 26);
		grade2.add(bttOK);
		
		JLabel lblPesquisa = new JLabel("Pesquisa");
		lblPesquisa.setBounds(23, 24, 63, 16);
		grade2.add(lblPesquisa);
		
		scrollz = new JScrollPane();
		scrollz.setBounds(0, 101, 621, 140);
		grade2.add(scrollz);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
			},
			new String[] {
				"Nome", "Raz�o Social", "Endere�o", "CNPJ", "Contato", "Descri��o"
			}
		));
		scrollz.setViewportView(table);
		
		panel = new JPanel();
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(192, 192, 192), null));
		panel.setBackground(new Color(0, 0, 128));
		panel.setBounds(42, 72, 621, 33);
		contentPane.add(panel);
		
		lblFornecedor_title = new JLabel("FORNECEDOR");
		lblFornecedor_title.setForeground(Color.WHITE);
		lblFornecedor_title.setFont(new Font("Arial", Font.PLAIN, 16));
		panel.add(lblFornecedor_title);
		
		panel_1 = new JPanel();
		panel_1.setBounds(-19, 409, 742, 496);
		contentPane.add(panel_1);
		panel_1.setBackground(SystemColor.activeCaption);
	}
}
