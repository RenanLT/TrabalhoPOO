package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Choice;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.ListSelectionModel;
import java.awt.TextArea;
import java.awt.SystemColor;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import java.awt.Font;

public class cadProduto extends JFrame {

	private JPanel contentPane;
	private JTextField txtCod;
	private JTextField txtNome;
	private JTextField txtQtd;
	private JTextField txtCod_ArmPK;
	private JTextField txtValor;
	private JTextField txtcnpjPK;
	private JTextField txtPesquisa;
	private JTable table;

	public static void main(String[] args) {
		try //design
		{
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) 
            {
                if ("Nimbus".equals(info.getName())) 
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        }
		catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) 
		{
             System.err.println(ex);        
        } 		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					cadProduto frame = new cadProduto();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public cadProduto() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 992);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		TextArea txtDescricao = new TextArea();
		txtDescricao.setRows(10);
		txtDescricao.setBounds(62, 403, 554, 93);
		contentPane.add(txtDescricao);
		
		txtCod = new JTextField();
		txtCod.setColumns(10);
		txtCod.setBounds(61, 135, 555, 24);
		contentPane.add(txtCod);
		
		JLabel lblCod = new JLabel("C\u00F3digo");
		lblCod.setBounds(61, 116, 56, 16);
		contentPane.add(lblCod);
		
		txtNome = new JTextField();
		txtNome.setColumns(10);
		txtNome.setBounds(61, 190, 555, 24);
		contentPane.add(txtNome);
		
		JLabel lblNome = new JLabel("Nome ");
		lblNome.setBounds(61, 172, 143, 16);
		contentPane.add(lblNome);		
		txtQtd = new JTextField();
		txtQtd.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char a= e.getKeyChar();
				if(!(Character.isDigit(a) || (a==KeyEvent.VK_BACK_SPACE) || a==KeyEvent.VK_DELETE))
				{
					e.consume(); 
				}
			}
		});
		txtQtd.setColumns(10);
		txtQtd.setBounds(61, 242, 130, 24);
		contentPane.add(txtQtd);
		
		JLabel lblQtd = new JLabel("Quantidade");
		lblQtd.setBounds(61, 223, 143, 16);
		contentPane.add(lblQtd);
		
		txtCod_ArmPK = new JTextField();
		txtCod_ArmPK.setColumns(10);
		txtCod_ArmPK.setBounds(61, 290, 555, 24);
		contentPane.add(txtCod_ArmPK);
		
		Choice situacao = new Choice();
		situacao.setBounds(441, 244, 175, 22);
		contentPane.add(situacao);
		situacao.add(">:(");
		situacao.add(">:)");
		
		JLabel lblSit = new JLabel("Situa\u00E7\u00E3o");
		lblSit.setBounds(441, 224, 56, 16);
		contentPane.add(lblSit);
		
		txtValor = new JTextField();
		txtValor.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char a= e.getKeyChar();
				if(!(Character.isDigit(a) || (a==KeyEvent.VK_BACK_SPACE) || a==KeyEvent.VK_DELETE))
				{
					e.consume(); 
				}
			}
		});
		txtValor.setColumns(10);
		txtValor.setBounds(253, 242, 130, 24);
		contentPane.add(txtValor);
		
		JLabel lblValor = new JLabel("Valor");
		lblValor.setBounds(253, 223, 143, 16);
		contentPane.add(lblValor);
		
		JLabel lblCod_ArmPK = new JLabel("C�digo do Armaz�m ");
		lblCod_ArmPK.setBounds(61, 273, 143, 16);
		contentPane.add(lblCod_ArmPK);
		
		JLabel lblcnpj = new JLabel("Fornecedor (CNPJ)");
		lblcnpj.setBounds(61, 327, 143, 16);
		contentPane.add(lblcnpj);
		
		txtcnpjPK = new JTextField();
		txtcnpjPK.setColumns(10);
		txtcnpjPK.setBounds(61, 344, 555, 24);
		contentPane.add(txtcnpjPK);
		
		JButton bttSalvar = new JButton("Salvar");
		bttSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg) 
			{
				//CtrlProduto adicionar = new CtrlProduto();
				//adicionar.inclui(conn, txtCod, txtNome, txtValor, txtDescricao, situacao, txtQtd, txtCod_ArmPK, txtcnpjPK);
				JOptionPane.showMessageDialog(null, " Dados cadastrados com sucesso! ", "Sucesso",JOptionPane.INFORMATION_MESSAGE);
				
			}
		});
		bttSalvar.setBounds(349, 516, 120, 37);
		contentPane.add(bttSalvar);
		
		JButton bttCancelar = new JButton("Cancelar");
		bttCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				if (JOptionPane.showConfirmDialog(null, " Tem certeza que deseja cancelar? \nOs dados n�o ser�o salvos. ", "Aten��o",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) 
				{
					  principal p = new principal();	
					  p.setVisible(true);
					  dispose();	
				} else 
				{
					  setVisible(true);						    
				}				
			
			}
		});
		bttCancelar.setBounds(496, 516, 120, 37);
		contentPane.add(bttCancelar);
		
		JLabel label_2 = new JLabel("Descri\u00E7\u00E3o");
		label_2.setBounds(58, 381, 56, 16);
		contentPane.add(label_2);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 702, 31);
		contentPane.add(menuBar);
		
		JMenu mnMenu = new JMenu("Menu | ");
		menuBar.add(mnMenu);
		
		JMenuItem mntmNovo = new JMenuItem("Novo");
		mnMenu.add(mntmNovo);
		mntmNovo.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				txtNome.setText("");
				txtCod.setText("");
				txtcnpjPK.setText("");
				txtValor.setText("");
				txtCod_ArmPK.setText("");	
				txtDescricao.setText(""); //esse nao esta funcionando :C
				txtValor.setText("");
			}	
			
		});
		
		
		JMenuItem mntmVoltar = new JMenuItem("Voltar");
		mnMenu.add(mntmVoltar);
		mntmVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
			   principal p = new principal();
			   p.setVisible(true);
			   dispose();			   
			}
		});
		
		JMenu mnAjuda = new JMenu("Ajuda");
		menuBar.add(mnAjuda);
		
		JMenuItem mntmSobre = new JMenuItem("Sobre");
		mnAjuda.add(mntmSobre);
		mntmSobre.addActionListener(new ActionListener() 
		{			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				sobre soulburn = new sobre();
				soulburn.setVisible(true);				
			}
		});
		
		JPanel grade2 = new JPanel();
		grade2.setLayout(null);
		grade2.setBorder(new CompoundBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(191, 205, 219), null), null));
		grade2.setBounds(33, 600, 621, 316);
		contentPane.add(grade2);
		
		JButton bttAlterar = new JButton("Alterar");
		bttAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, " Dados alterados! ", "Altera��o ",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		bttAlterar.setBounds(312, 266, 120, 37);
		grade2.add(bttAlterar);
		
		JButton bttRemover = new JButton("Remover");
		bttRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, " Dados removidos! ", "Remo��o ",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		bttRemover.setBounds(456, 266, 120, 37);
		grade2.add(bttRemover);
		
		txtPesquisa = new JTextField();
		txtPesquisa.setColumns(10);
		txtPesquisa.setBounds(23, 44, 243, 26);
		grade2.add(txtPesquisa);
		
		JButton bttOK = new JButton("OK");
		bttOK.setBounds(278, 44, 49, 26);
		grade2.add(bttOK);
		
		JLabel lblPesquisa = new JLabel("Pesquisa");
		lblPesquisa.setBounds(23, 24, 63, 16);
		grade2.add(lblPesquisa);
		
		JScrollPane scrollsanto = new JScrollPane();
		scrollsanto.setBounds(0, 94, 621, 147);
		grade2.add(scrollsanto);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
			},
			new String[] {
			"C�digo do Produto", "Nome", "Qauntidade", "Valor", "Data" ,"Situa��o", "C�digo do Armaz�m", "Fornecedor(CNPJ)", "Descri��o"
			}
		));
		scrollsanto.setViewportView(table);
		
		JPanel grade1 = new JPanel();
		grade1.setBorder(new CompoundBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), null));
		grade1.setBounds(33, 101, 621, 470);
		contentPane.add(grade1);
		grade1.setLayout(null);
		
		JPanel bg = new JPanel();
		bg.setBackground(SystemColor.activeCaption);
		bg.setBounds(-13, 442, 725, 523);
		contentPane.add(bg);
		
		JPanel panel = new JPanel();
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(192, 192, 192), null));
		panel.setBackground(new Color(0, 0, 128));
		panel.setBounds(33, 60, 621, 33);
		contentPane.add(panel);
		
		JLabel lblProdutos = new JLabel("PRODUTO");
		lblProdutos.setForeground(Color.WHITE);
		lblProdutos.setFont(new Font("Arial", Font.PLAIN, 16));
		panel.add(lblProdutos);
	}
}
