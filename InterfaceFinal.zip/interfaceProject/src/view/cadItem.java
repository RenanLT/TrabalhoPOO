package view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.ListSelectionModel;
import java.awt.SystemColor;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import java.awt.Font;
import javax.swing.SwingConstants;

public class cadItem extends JFrame {

	private JPanel contentPane;
	private JTextField txtCod;
	private JTextField txtQtd;
	private JTextField txtCodProduto;
	private JTextField txtCodPedido;
	private JTextField txtPesquisa;
	private JTable table;
	
	public static void main(String[] args) {
		try //design
		{
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) 
            {
                if ("Nimbus".equals(info.getName())) 
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) 
		{
            System.err.println(ex);        
        }
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					cadItem frame = new cadItem();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public cadItem() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 707, 820);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.menu);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 701, 32);
		contentPane.add(menuBar);
		
		JMenu mnMenu = new JMenu("Menu |");
		menuBar.add(mnMenu);
		
		JMenuItem mntmNovo = new JMenuItem("Novo");
		mnMenu.add(mntmNovo);
		mntmNovo.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				txtCod.setText("");
				txtCodPedido.setText("");
				txtCodProduto.setText("");
				txtQtd.setText("");
			}	
			
		});
		
		JMenuItem mntmVoltar = new JMenuItem("Voltar");
		mnMenu.add(mntmVoltar);
		mntmVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
			   principal p = new principal();
			   p.setVisible(true);
			   dispose();			   
			}
		});
		
		JMenu mnAjuda = new JMenu("Ajuda");
		menuBar.add(mnAjuda);
		
		JMenuItem mntmSobre = new JMenuItem("Sobre");
		mnAjuda.add(mntmSobre);
		mntmSobre.addActionListener(new ActionListener() 
		{			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				sobre soulburn = new sobre();
				soulburn.setVisible(true);				
			}
		});
		
		JPanel grade1 = new JPanel();
		grade1.setLayout(null);
		grade1.setBorder(new CompoundBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(191, 205, 219), null), null));
		grade1.setBounds(30, 90, 632, 316);
		contentPane.add(grade1);
		
		txtCodPedido = new JTextField();
		txtCodPedido.setBounds(27, 222, 555, 22);
		grade1.add(txtCodPedido);
		txtCodPedido.setColumns(1);
		
		JLabel lblCdigoDoPedido = new JLabel("C\u00F3digo do Pedido");
		lblCdigoDoPedido.setBounds(27, 205, 114, 16);
		grade1.add(lblCdigoDoPedido);
		
		JButton bttSalvar = new JButton("Salvar");
		bttSalvar.setBounds(317, 266, 120, 37);
		grade1.add(bttSalvar);
		
		JButton bttCancelar = new JButton("Cancelar");
		bttCancelar.setBounds(462, 266, 120, 37);
		grade1.add(bttCancelar);
		
		txtCodProduto = new JTextField();
		txtCodProduto.setBounds(27, 164, 555, 22);
		grade1.add(txtCodProduto);
		txtCodProduto.setColumns(1);
		
		JLabel lblCodProd = new JLabel("C\u00F3digo do Produto");
		lblCodProd.setBounds(28, 146, 113, 16);
		grade1.add(lblCodProd);
		
		txtQtd = new JTextField();
		txtQtd.setBounds(27, 104, 555, 22);
		grade1.add(txtQtd);
		txtQtd.setColumns(1);
		
		JLabel lblQtd = new JLabel("Quantidade");
		lblQtd.setBounds(27, 86, 97, 16);
		grade1.add(lblQtd);
		
		txtCod = new JTextField();
		txtCod.setBounds(27, 49, 555, 22);
		grade1.add(txtCod);
		txtCod.setColumns(1);
		
		JLabel lblCodigo = new JLabel("C\u00F3digo");
		lblCodigo.setBounds(28, 30, 56, 16);
		grade1.add(lblCodigo);
		
		JPanel grade2 = new JPanel();
		grade2.setLayout(null);
		grade2.setBorder(new CompoundBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(191, 205, 219), null), null));
		grade2.setBounds(30, 438, 632, 316);
		contentPane.add(grade2);
		
		JButton bttAlterar = new JButton("Alterar");
		bttAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, " Dados alterados! ", "Altera��o ",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		bttAlterar.setBounds(312, 266, 120, 37);
		grade2.add(bttAlterar);
		
		JButton BttRemover = new JButton("Remover");
		BttRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, " Dados removidos! ", "Remo��o ",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		BttRemover.setBounds(456, 266, 120, 37);
		grade2.add(BttRemover);
		
		txtPesquisa = new JTextField();
		txtPesquisa.setColumns(10);
		txtPesquisa.setBounds(23, 44, 243, 26);
		grade2.add(txtPesquisa);
		
		JButton bttOK = new JButton("OK");
		bttOK.setBounds(278, 44, 49, 26);
		grade2.add(bttOK);
		
		JLabel lblPesquisa = new JLabel("Pesquisa");
		lblPesquisa.setBounds(23, 24, 63, 16);
		grade2.add(lblPesquisa);
		
		JScrollPane scroll = new JScrollPane();
		scroll.setBounds(0, 97, 632, 139);
		grade2.add(scroll);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
			},
			new String[] {
				"C�digo do Item", "Quantidade", "C�digo do Produto", "C�digo do Pedido"
			}
		));
		scroll.setViewportView(table);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.activeCaption);
		panel.setBounds(-11, 363, 725, 437);
		contentPane.add(panel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(192, 192, 192), null));
		panel_1.setBackground(new Color(0, 0, 128));
		panel_1.setBounds(30, 49, 632, 33);
		contentPane.add(panel_1);
		
		JLabel lblItens = new JLabel("ITEM");
		lblItens.setHorizontalAlignment(SwingConstants.CENTER);
		lblItens.setForeground(new Color(255, 255, 255));
		lblItens.setFont(new Font("Arial", Font.PLAIN, 16));
		panel_1.add(lblItens);
		bttCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg) 
			{
				if (JOptionPane.showConfirmDialog(null, " Tem certeza que deseja cancelar? \nOs dados n�o ser�o salvos. ", "Aten��o",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) 
				{
					  principal p = new principal();	
					  p.setVisible(true);
					  dispose();	
				} else 
				{
					  setVisible(true);						    
				}				
			}
		});
		bttSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				//CtrlItem adicionar = new CtrlItem(); FUN��O CONTROLE, TIRE DO COMENT�RIO PARA QUE POSSA SER IMPLEMENTADO
				//adicionar.inclui(conn, txtCod, txtQtd, txtCodProduto, txtCodPedido);
				JOptionPane.showMessageDialog(null, " Dados cadastrados com sucesso! ", "Sucesso",JOptionPane.INFORMATION_MESSAGE);
			}
		});
	}

}
