package view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import java.awt.Window.Type;
import java.awt.SystemColor;
import javax.swing.border.EtchedBorder;
import javax.swing.SwingConstants;
import java.awt.Toolkit;

public class principal extends JFrame {

	private JPanel contentPane;

	public static void main(String[] args) {
		try //design
		{
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) 
            {
                if ("Nimbus".equals(info.getName())) 
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) 
		{
            System.err.println(ex);        
        }
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					principal frame = new principal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public principal() {
		setTitle("Projeto POO");
		setFont(new Font("Arial", Font.PLAIN, 12));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 827, 664);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel_forn = new JPanel();
		panel_forn.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_forn.setBackground(new Color(204, 51, 102));
		panel_forn.setLayout(null);
		panel_forn.setBounds(12, 212, 387, 184);
		contentPane.add(panel_forn);
		
		JPanel panel_8 = new JPanel();
		panel_8.setBackground(new Color(204, 0, 51));
		panel_8.setLayout(null);
		panel_8.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, SystemColor.inactiveCaption));
		panel_8.setBounds(0, 0, 387, 36);
		panel_forn.add(panel_8);
		
		JLabel TITLECadastrar_Forn = new JLabel("CADASTRAR / CONSULTAR");
		TITLECadastrar_Forn.setHorizontalAlignment(SwingConstants.CENTER);
		TITLECadastrar_Forn.setForeground(new Color(255, 255, 255));
		TITLECadastrar_Forn.setFont(new Font("Tahoma", Font.PLAIN, 14));
		TITLECadastrar_Forn.setBackground(Color.BLACK);
		TITLECadastrar_Forn.setBounds(12, 0, 167, 36);
		panel_8.add(TITLECadastrar_Forn);
		
		JButton btnFornecedor = new JButton("Fornecedor");
		btnFornecedor.setBounds(73, 88, 242, 36);
		panel_forn.add(btnFornecedor);
		
		JLabel lbl_fornimg = new JLabel("");
		lbl_fornimg.setBounds(34, 40, 284, 144);
		panel_forn.add(lbl_fornimg);
		Image img2 = new ImageIcon(this.getClass().getResource("/truck.png")).getImage();
		lbl_fornimg.setIcon(new ImageIcon(img2));
		
		btnFornecedor.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent go) 
			{
				cadFornecedor fornecedor = new cadFornecedor();	
				fornecedor.setVisible(true);
			}
		});
		
		JPanel panel_arm = new JPanel();
		panel_arm.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_arm.setBackground(new Color(153, 102, 255));
		panel_arm.setLayout(null);
		panel_arm.setBounds(411, 212, 387, 184);
		contentPane.add(panel_arm);
		
		JPanel panel_9 = new JPanel();
		panel_9.setBackground(new Color(255, 255, 255));
		panel_9.setLayout(null);
		panel_9.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, SystemColor.inactiveCaption));
		panel_9.setBounds(0, 0, 387, 36);
		panel_arm.add(panel_9);
		
		JLabel TITLECadastrar_PedPag = new JLabel("CADASTRAR / CONSULTAR");
		TITLECadastrar_PedPag.setHorizontalAlignment(SwingConstants.CENTER);
		TITLECadastrar_PedPag.setForeground(Color.BLACK);
		TITLECadastrar_PedPag.setFont(new Font("Tahoma", Font.PLAIN, 14));
		TITLECadastrar_PedPag.setBackground(Color.BLACK);
		TITLECadastrar_PedPag.setBounds(12, 0, 167, 36);
		panel_9.add(TITLECadastrar_PedPag);
		
		
		
		JButton btnPedido = new JButton("Pedido");
		btnPedido.setBounds(73, 76, 242, 36);
		panel_arm.add(btnPedido);
		
		JButton btnPagamento = new JButton("Pagamento");
		btnPagamento.setBounds(73, 114, 242, 36);
		panel_arm.add(btnPagamento);
		
		JLabel lbl_img_ped = new JLabel("");
		lbl_img_ped.setBounds(0, 37, 387, 147);
		panel_arm.add(lbl_img_ped);
		Image img1 = new ImageIcon(this.getClass().getResource("/pedido2.png")).getImage();
		lbl_img_ped.setIcon(new ImageIcon(img1));
		
		btnPagamento.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				cadPagamento pgm = new cadPagamento();	
				pgm.setVisible(true);
			}
		});
		btnPedido.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent go) 
			{
				cadPedido Pedido = new cadPedido();
				Pedido.setVisible(true);
			}
		});
		
		JPanel cli_panel = new JPanel();
		cli_panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		cli_panel.setBackground(Color.ORANGE);
		cli_panel.setBounds(12, 15, 387, 184);
		contentPane.add(cli_panel);
		cli_panel.setLayout(null);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBackground(new Color(255, 228, 181));
		panel_6.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, SystemColor.inactiveCaption));
		panel_6.setBounds(0, 0, 387, 36);
		cli_panel.add(panel_6);
		panel_6.setLayout(null);
		
		JLabel TITLECadastrar_Cli = new JLabel("CADASTRAR / CONSULTAR");
		TITLECadastrar_Cli.setHorizontalAlignment(SwingConstants.CENTER);
		TITLECadastrar_Cli.setForeground(new Color(0, 0, 0));
		TITLECadastrar_Cli.setFont(new Font("Tahoma", Font.PLAIN, 14));
		TITLECadastrar_Cli.setBackground(new Color(0, 0, 0));
		TITLECadastrar_Cli.setBounds(12, 0, 167, 36);
		panel_6.add(TITLECadastrar_Cli);
		
		JButton btnCJ = new JButton("Cliente Jur\u00EDdico");
		btnCJ.setBounds(73, 114, 242, 36);
		cli_panel.add(btnCJ);
		
		JButton btnCF = new JButton("Cliente F\u00EDsico");
		btnCF.setBounds(73, 76, 242, 36);
		cli_panel.add(btnCF);
		
		JLabel label_Cli_Img = new JLabel("");
		label_Cli_Img.setBounds(-50, 36, 437, 148);
		cli_panel.add(label_Cli_Img);
		Image img = new ImageIcon(this.getClass().getResource("/cli_jurid.png")).getImage();
		label_Cli_Img.setIcon(new ImageIcon(img));
		btnCF.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent go) 
			{
				Cliente_Fisico cliFisico = new Cliente_Fisico();	
				cliFisico.setVisible(true);
			}
		});
		btnCJ.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent go) 
			{
				Cliente_Juridico cliJuridico = new Cliente_Juridico();	
				cliJuridico.setVisible(true);
			}
		});
		
		JPanel panel_item = new JPanel();
		panel_item.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_item.setLayout(null);
		panel_item.setBackground(new Color(102, 204, 255));
		panel_item.setBounds(12, 409, 387, 186);
		contentPane.add(panel_item);
		
		JButton btnItem = new JButton("Item");
		btnItem.setBounds(73, 76, 242, 36);
		panel_item.add(btnItem);
		
		JButton btnProduto = new JButton("Produto");
		btnProduto.setBounds(73, 114, 242, 36);
		panel_item.add(btnProduto);
		
		JPanel panel_10 = new JPanel();
		panel_10.setBackground(SystemColor.textHighlight);
		panel_10.setLayout(null);
		panel_10.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, SystemColor.inactiveCaption));
		panel_10.setBounds(0, 0, 387, 36);
		panel_item.add(panel_10);
		
		JLabel TITLECadastrar_It = new JLabel("CADASTRAR / CONSULTAR");
		TITLECadastrar_It.setHorizontalAlignment(SwingConstants.CENTER);
		TITLECadastrar_It.setForeground(Color.WHITE);
		TITLECadastrar_It.setFont(new Font("Tahoma", Font.PLAIN, 14));
		TITLECadastrar_It.setBackground(Color.BLACK);
		TITLECadastrar_It.setBounds(12, 0, 167, 36);
		panel_10.add(TITLECadastrar_It);
		
		JLabel lbl_ItemImg = new JLabel("");
		lbl_ItemImg.setBounds(0, 13, 267, 194);
		Image img4 = new ImageIcon(this.getClass().getResource("/check_.png")).getImage();
		lbl_ItemImg.setIcon(new ImageIcon(img4));
		panel_item.add(lbl_ItemImg);
		btnProduto.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent a) 
			{
				cadProduto produto = new cadProduto();	
				produto.setVisible(true);
			}
		});
		btnItem.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent go) 
			{
				cadItem Item = new cadItem();	
				Item.setVisible(true);
			}
		});
		
		JPanel panel_none = new JPanel();
		panel_none.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_none.setLayout(null);
		panel_none.setBackground(new Color(192, 192, 192));
		panel_none.setBounds(411, 409, 387, 186);
		contentPane.add(panel_none);
		
		JPanel panel_pedido = new JPanel();
		panel_pedido.setBounds(411, 15, 387, 184);
		contentPane.add(panel_pedido);
		panel_pedido.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_pedido.setBackground(new Color(154, 205, 50));
		panel_pedido.setLayout(null);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBackground(new Color(189, 183, 107));
		panel_7.setLayout(null);
		panel_7.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, SystemColor.inactiveCaption));
		panel_7.setBounds(0, 0, 387, 36);
		panel_pedido.add(panel_7);
		
		JLabel TITLECadastrar_Arm = new JLabel("CADASTRAR / CONSULTAR");
		TITLECadastrar_Arm.setHorizontalAlignment(SwingConstants.CENTER);
		TITLECadastrar_Arm.setForeground(Color.WHITE);
		TITLECadastrar_Arm.setFont(new Font("Tahoma", Font.PLAIN, 14));
		TITLECadastrar_Arm.setBackground(Color.BLACK);
		TITLECadastrar_Arm.setBounds(12, 0, 167, 36);
		panel_7.add(TITLECadastrar_Arm);
		
		JButton btnArmazem = new JButton("Armaz\u00E9m");
		btnArmazem.setBounds(73, 88, 242, 36);
		panel_pedido.add(btnArmazem);
		
		JLabel lbl_ArmIMG = new JLabel("");
		lbl_ArmIMG.setVerticalAlignment(SwingConstants.TOP);
		lbl_ArmIMG.setBounds(107, 0, 290, 184);
		panel_pedido.add(lbl_ArmIMG);
		Image img3 = new ImageIcon(this.getClass().getResource("/warehouse.png")).getImage();
		lbl_ArmIMG.setIcon(new ImageIcon(img3));
		btnArmazem.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent go) 
			{
				cadArmazem arm = new cadArmazem();	
				arm.setVisible(true);
			}
		});		
	}
}
