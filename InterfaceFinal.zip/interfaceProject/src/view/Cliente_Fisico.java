package view;

import java.awt.Choice;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;


import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.TextArea;
import java.awt.List;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import com.toedter.calendar.JDateChooser;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JDesktopPane;
import javax.swing.border.BevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.border.LineBorder;
import java.awt.FlowLayout;
import javax.swing.border.CompoundBorder;
import java.awt.SystemColor;
import java.awt.BorderLayout;
import javax.swing.UIManager;
import javax.swing.border.EtchedBorder;
import java.awt.Toolkit;
import javax.swing.ListSelectionModel;
import java.awt.Font;

public class Cliente_Fisico extends JFrame {

	private JPanel txtNome;
	private JTextField txtnome;
	private JTextField textMat;
	private JTextField textContato;
	private JTextField textEndereco;
	private JTextField textCpf;
	private JLabel lblMatricula;
	private JLabel lblContato;
	private JLabel lblSituacao;
	private JLabel lblCpf;
	private JLabel lblSexo;
	private JMenuBar menuBar;
	private JMenu mnMenu;
	private JMenu mnSobre;
	private JMenuItem mntmNovo;
	private JMenuItem mntmVoltar;
	private JMenuItem mntmSobre;
	private JTextField txtPesquisa;
	private JButton btnOk;
	private JLabel lblPesquisa;
	private JPanel Grade2;
	private JButton btnAlterar;
	private JButton btnRemover;
	private JPanel bg;
	private JScrollPane scroll;
	private JTable tablezzz;
	private JPanel panel;
	private JLabel lblCliente_title;
	
	public static void main(String[] args) {
		try //design
		{
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) 
            {
                if ("Nimbus".equals(info.getName())) 
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) 
		{
            System.err.println(ex);        
        }
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cliente_Fisico frame = new Cliente_Fisico();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public Cliente_Fisico() 
	{
		setResizable(false);
		setForeground(Color.WHITE);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 720, 830);
		txtNome = new JPanel();
		txtNome.setBackground(Color.WHITE);
		txtNome.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(txtNome);
		txtNome.setLayout(null);
		
		JLabel lblNomeCompleto = new JLabel("Nome Completo");
		lblNomeCompleto.setBounds(69, 120, 109, 16);
		txtNome.add(lblNomeCompleto);
		
		txtnome = new JTextField();
		txtnome.setBounds(69, 141, 555, 24);
		txtNome.add(txtnome);
		txtnome.setColumns(10);
		
		textMat = new JTextField();
		textMat.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent event) 
			{
				char c= event.getKeyChar();
				if(!(Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE) || c==KeyEvent.VK_DELETE))
				{
					event.consume(); //n�o � type;
				}
				
			}
		});
		textMat.setBounds(69, 206, 234, 24);
		textMat.setColumns(10);
		txtNome.add(textMat);
		
		textContato = new JTextField();
		textContato.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) //** aceite apenas numeros
			{
				char c= e.getKeyChar();
				if(!(Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE) || c==KeyEvent.VK_DELETE))
				{
					e.consume(); 
				}
			}
		});
		textContato.setBounds(364, 206, 260, 24);
		textContato.setColumns(10);
		txtNome.add(textContato);
		
		JLabel lblEndereco = new JLabel("Endere\u00E7o");
		lblEndereco.setBounds(69, 255, 53, 16);
		txtNome.add(lblEndereco);
		
		textEndereco = new JTextField();
		textEndereco.setBounds(69, 274, 395, 24);
		textEndereco.setColumns(10);
		txtNome.add(textEndereco);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(494, 274, 125, 24);
		txtNome.add(dateChooser);
		
		JLabel lblData = new JLabel("Data");
		lblData.setBounds(494, 255, 75, 16);
		txtNome.add(lblData);
		
		Choice situacao = new Choice();
		situacao.setBounds(69, 334, 175, 22);
		txtNome.add(situacao);
		situacao.add(":(");
		situacao.add(":)");
		
		textCpf = new JTextField();
		textCpf.setBounds(290, 334, 175, 22);
		textCpf.setColumns(10);
		txtNome.add(textCpf);
		
		Choice sexo = new Choice();
		sexo.setBounds(494, 334, 75, 22);
		txtNome.add(sexo);
		sexo.add("F");
		sexo.add("M");
	    
		lblMatricula = new JLabel("Matr\u00EDcula");
		lblMatricula.setBounds(69, 187, 56, 16);
		txtNome.add(lblMatricula);
		
		lblContato = new JLabel("Contato");
		lblContato.setBounds(364, 187, 56, 16);
		txtNome.add(lblContato);
		
		lblSituacao = new JLabel("Situa\u00E7\u00E3o");
		lblSituacao.setBounds(69, 312, 56, 16);
		txtNome.add(lblSituacao);
		
		lblCpf = new JLabel("CPF");
		lblCpf.setBounds(290, 312, 56, 16);
		txtNome.add(lblCpf);
		
		lblSexo = new JLabel("Sexo");
		lblSexo.setBounds(494, 312, 56, 16);
		txtNome.add(lblSexo);
		
		menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 818, 33);
		txtNome.add(menuBar);
		
		mnMenu = new JMenu("Menu  |");
		menuBar.add(mnMenu);
		
		mntmNovo = new JMenuItem("Novo");
		mnMenu.add(mntmNovo);
		mntmNovo.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				txtnome.setText("");
				lblSituacao.setText("");
				//txtPesquisa.setText("");
				lblSexo.setText("");
				textCpf.setText("");
				textContato.setText("");
				textEndereco.setText("");	
				textMat.setText("");
			}				
		});	
		
		mntmVoltar = new JMenuItem("Voltar");
		mnMenu.add(mntmVoltar);
		mntmVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
			   principal p = new principal();
			   p.setVisible(true);
			   dispose();			   
			}
		});
		
		mnSobre = new JMenu("Ajuda");
		menuBar.add(mnSobre);
		
		mntmSobre = new JMenuItem("Sobre");
		mnSobre.add(mntmSobre);	
		mntmSobre.addActionListener(new ActionListener() 
		{			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				sobre soulburn = new sobre();
				soulburn.setVisible(true);				
			}
		});
		
		JPanel Grade1 = new JPanel();
		Grade1.setBorder(new CompoundBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(191, 205, 219), new Color(180, 180, 180)), null));
		Grade1.setBounds(36, 89, 632, 316);
		txtNome.add(Grade1);
		Grade1.setLayout(null);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.setBounds(312, 275, 120, 37);
		Grade1.add(btnSalvar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setBounds(456, 276, 120, 37);
		Grade1.add(btnCancelar);
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				if (JOptionPane.showConfirmDialog(null, " Tem certeza que deseja cancelar? \nOs dados n�o ser�o salvos. ", "Aten��o",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) 
				{
					  principal p = new principal();	
					  p.setVisible(true);
					  dispose();	
				} else 
				{
					  setVisible(true);						    
				}				
			}
		});
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent salvar) 
			{
				//CtrCliente adicionar = new CtrCliente(); FUN��O CONTROLE, TIRE DO COMENT�RIO PARA QUE POSSA SER IMPLEMENTADO
				//adicionar.inclui(conn, textMat, txtnome, textContato, textEndereco, situacao, textCpf, sexo, Data);
				JOptionPane.showMessageDialog(null, " Dados cadastrados com sucesso! ", "Sucesso",JOptionPane.INFORMATION_MESSAGE);
				
			}
		});
		
		
		Grade2 = new JPanel();
		Grade2.setLayout(null);
		Grade2.setBorder(new CompoundBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(191, 205, 219), new Color(180, 180, 180)), null));
		Grade2.setBounds(36, 432, 632, 316);
		txtNome.add(Grade2);
		
		btnAlterar = new JButton("Alterar");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg) {
				JOptionPane.showMessageDialog(null, " Dados alterados! ", "Altera��o ",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnAlterar.setBounds(312, 266, 120, 37);
		Grade2.add(btnAlterar);
		
		btnRemover = new JButton("Remover");
		btnRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, " Dados removidos! ", "Remo��o ",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnRemover.setBounds(456, 266, 120, 37);
		Grade2.add(btnRemover);
		
		txtPesquisa = new JTextField();
		txtPesquisa.setBounds(23, 44, 243, 26);
		Grade2.add(txtPesquisa);
		txtPesquisa.setColumns(10);
		
		btnOk = new JButton("OK");
		btnOk.setIcon(null);
		btnOk.setBounds(278, 44, 49, 26);
		Grade2.add(btnOk);
		
		lblPesquisa = new JLabel("Pesquisa");
		lblPesquisa.setBounds(23, 24, 63, 16);
		Grade2.add(lblPesquisa);
		
		scroll = new JScrollPane();
		scroll.setBounds(0, 98, 632, 138);
		Grade2.add(scroll);
		
		tablezzz = new JTable();
		tablezzz.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
			},
			new String[] {
				"Nome Completo", "Matr�cula", "Contato", "Endere�o", "Data", "Situa��o", "CPF", "Sexo"
			}
		));
		scroll.setViewportView(tablezzz);
		
		bg = new JPanel();
		bg.setBackground(SystemColor.activeCaption);
		bg.setBounds(0, 351, 718, 453);
		txtNome.add(bg);
		bg.setLayout(null);
		
		panel = new JPanel();
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(192, 192, 192), null));
		panel.setBackground(new Color(0, 0, 128));
		panel.setBounds(36, 49, 632, 33);
		txtNome.add(panel);
		panel.setLayout(null);
		
		lblCliente_title = new JLabel("CLIENTE FISICO");
		lblCliente_title.setBounds(267, 0, 197, 32);
		lblCliente_title.setForeground(Color.WHITE);
		lblCliente_title.setFont(new Font("Arial", Font.PLAIN, 16));
		panel.add(lblCliente_title);
		
	}
}
