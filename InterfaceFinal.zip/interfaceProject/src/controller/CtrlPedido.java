package controller;

import java.util.*; // Em fun��o da classe ArrayList
import java.sql.*;

public class CtrlPedido
{   
  public CtrlPedido(String string, String string2, double double1, String string3, String string4) {
		// TODO Auto-generated constructor stub
	}

public static int inclui (Connection conn, int codigo, String data, double valor, String situacao,
      int cliente_matricula) 
    throws SQLException
  {   
    PreparedStatement pstmt = conn.prepareStatement
      ("select Pedido_seq.nextval as contador from sys.dual");
    ResultSet rs = pstmt.executeQuery();
    rs.next();
    int pk = rs.getInt("contador");
    rs.close();
    pstmt.close();
    
    pstmt = conn.prepareStatement
      ("insert into Pedido(codigo, data, valor, situacao, cliente_matricula) values(?, ?, ?, ?, ?)");
    pstmt.setInt(1, codigo);
    pstmt.setString(2, data);
    pstmt.setDouble(3, valor);
    pstmt.setString(4, situacao);
    pstmt.setInt(5, cliente_matricula);
    
    
    pstmt.executeUpdate();
    pstmt.close();
    
    return pk;
  }

  public static boolean altera(Connection conn, int codigo, String data, double valor, String situacao,
      int cliente_matricula) 
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("update Pedido set data = ?, valor = ?, situacao = ?, cliente_matricula = ? where codigo = ?");
    pstmt.setString(1, data);
    pstmt.setDouble(2, valor);
    pstmt.setString(3, situacao);
    pstmt.setInt(4, cliente_matricula);
    pstmt.setInt(5, codigo);
    
    int n = pstmt.executeUpdate();

    pstmt.close();
    
    return n == 1;
  }


  public static boolean exclui (Connection conn, int codigo) 
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("delete from Pedido where codigo = ?");
    pstmt.setInt(1, codigo);
    
    int n = pstmt.executeUpdate();
    
    pstmt.close();
    
    return n == 1;
  }

  public static CtrlPedido recuperaUmPedido(Connection conn, int codigo)
  { CtrlPedido umPedido = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Pedido where codigo = ?");
      pstmt.setInt(1, codigo);
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { umPedido = new CtrlPedido(rs.getString("codigo"),
                                      rs.getString("data"),
                                      rs.getDouble("valor"),
                                      rs.getString("situacao"),
                                      rs.getString("cliente_matricula"));
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return umPedido;
  }

  public static ArrayList<CtrlPedido> recuperaPedido(Connection conn)
  { ArrayList<CtrlPedido> arrayPedido = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Pedido");
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { arrayPedido = new ArrayList<CtrlPedido>(20);
        do
        { arrayPedido.add(new CtrlPedido(rs.getString("codigo"),
                                             rs.getString("data"),
                                             rs.getDouble("valor"),
                                             rs.getString("situacao"),
                                             rs.getString("cliente_matricula")));
        }
        while(rs.next());
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return arrayPedido;
  }
}

