package controller;


import java.util.*; // Em fun��o da classe ArrayList
import java.sql.*;

public class CtrlCliente_Juridico
{   
  public CtrlCliente_Juridico(int int1, String string) {
		// TODO Auto-generated constructor stub
	}

public CtrlCliente_Juridico(int int1, String string, String string2) {
	// TODO Auto-generated constructor stub
}

public static int inclui (Connection conn,int cnpj, String razao_social) 
    throws SQLException
  {   
    PreparedStatement pstmt = conn.prepareStatement
      ("select Cliente_Juridico_seq.nextval as contador from sys.dual");
    ResultSet rs = pstmt.executeQuery();
    rs.next();
    int pk = rs.getInt("contador");
    rs.close();
    pstmt.close();
    
    pstmt = conn.prepareStatement
      ("insert into Cliente_Juridico(cnpj, razao_social) values(?, ?)");
    pstmt.setInt(1, cnpj);
    pstmt.setString(2, razao_social);
    
    
    pstmt.executeUpdate();
    pstmt.close();
    
    return pk;
  }

  public static boolean altera(Connection conn, int cnpj, String razao_social) 
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("update Cliente_Juridico set razao_social = ? where cnpj = ?");
    pstmt.setInt(1, cnpj);
    pstmt.setString(2, razao_social);
    
    
    int n = pstmt.executeUpdate();

    pstmt.close();
    
    return n == 1;
  }


  public static boolean exclui (Connection conn, String cnpj) 
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("delete from Cliente_Juridico where cnpj = ?");
    pstmt.setString(1, cnpj);
    
    int n = pstmt.executeUpdate();
    
    pstmt.close();
    
    return n == 1;
  }

  public static CtrlCliente_Juridico recuperaUmCliente_Juridico(Connection conn, int cnpj, String razao_social)
  { CtrlCliente_Juridico umCliente_Juridico = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Cliente_Juridico where cnpj = ?");
      pstmt.setInt(1, cnpj);
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { umCliente_Juridico = new CtrlCliente_Juridico(rs.getInt("cnpj"),
                                      rs.getString("razao_social"));
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return umCliente_Juridico;
  }

  public static ArrayList<CtrlCliente_Juridico> recuperaCliente_Juridico(Connection conn)
  { ArrayList<CtrlCliente_Juridico> arrayCliente_Juridico = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Cliente_Juridico");
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { arrayCliente_Juridico = new ArrayList<CtrlCliente_Juridico>(20);
        do
        { arrayCliente_Juridico.add(new CtrlCliente_Juridico(rs.getInt("cnpj"),
                                      rs.getString("razao_social"),
                                      rs.getString("contato")));
        }
        while(rs.next());
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return arrayCliente_Juridico;
  }
}
