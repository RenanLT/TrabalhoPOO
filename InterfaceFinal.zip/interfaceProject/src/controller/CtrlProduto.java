package controller;

import java.util.*; // Em fun��o da classe ArrayList
import java.sql.*;

public class CtrlProduto
{   
  public CtrlProduto(int int1, String string, double double1, String string2, String string3, int int2, int int3,
			int int4) {
		// TODO Auto-generated constructor stub
	}

public static int inclui (Connection conn, int codigo, String nome, double preco, String descricao, String situacao, int quantidade, int armazem_codigo, int fornecedor_cnpj) 
    throws SQLException
  {   
    PreparedStatement pstmt = conn.prepareStatement
      ("select Produto_seq.nextval as contador from sys.dual");
    ResultSet rs = pstmt.executeQuery();
    rs.next();
    int pk = rs.getInt("contador");
    rs.close();
    pstmt.close();
    
    pstmt = conn.prepareStatement
      ("insert into Produto(codigo, nome, preco, descricao, situacao) values(?, ?, ?, ?, ?)");
    pstmt.setInt(1, codigo);
    pstmt.setString(2, nome);
    pstmt.setDouble(3, preco);
    pstmt.setString(4, descricao);
    pstmt.setString(5, situacao);
    pstmt.setInt(6, quantidade);
    pstmt.setInt(7, armazem_codigo);
    pstmt.setInt(8, fornecedor_cnpj);
    
    
    pstmt.executeUpdate();
    pstmt.close();
    
    return pk;
  }

  public static boolean altera(Connection conn, int codigo, String nome, double preco, String descricao,
      String situacao, int quantidade, int armazem_codigo, int fornecedor_cnpj)  
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("update Produto set nome = ?, preco = ?, descricao = ?, situacao = ?, quantidade = ?, armazem_codigo = ?, fornecedor_cnpj = ? where codigo = ?");
    pstmt.setString(1, nome);
    pstmt.setDouble(2, preco);
    pstmt.setString(3, descricao);
    pstmt.setString(4, situacao);
    pstmt.setInt(5, quantidade);
    pstmt.setInt(6, armazem_codigo);
    pstmt.setInt(7, fornecedor_cnpj);
    pstmt.setInt(8, codigo);

    
    int n = pstmt.executeUpdate();

    pstmt.close();
    
    return n == 1;
  }


  public static boolean exclui (Connection conn, int codigo) 
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("delete from Produto where codigo = ?");
    pstmt.setInt(1, codigo);
    
    int n = pstmt.executeUpdate();
    
    pstmt.close();
    
    return n == 1;
  }

  public static CtrlProduto recuperaUmProduto(Connection conn, int codigo)
  { CtrlProduto umProduto = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Produto where codigo = ?");
      pstmt.setInt(1, codigo);
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { umProduto = new CtrlProduto(rs.getInt("codigo"),
                                      rs.getString("nome"),
                                      rs.getDouble("preco"),
                                      rs.getString("descricao"),
                                      rs.getString("situacao"),
                                      rs.getInt("quantidade"),
                                      rs.getInt("armazem_codigo"),
                                      rs.getInt("fornecedor_cnpj"));
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return umProduto;
  }

  public static ArrayList<CtrlProduto> recuperaProduto(Connection conn)
  { ArrayList<CtrlProduto> arrayProduto = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Produto");
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { arrayProduto = new ArrayList<CtrlProduto>(20);
        do
        { arrayProduto.add(new CtrlProduto(rs.getInt("codigo"),
                                      rs.getString("nome"),
                                      rs.getDouble("preco"),
                                      rs.getString("descricao"),
                                      rs.getString("situacao"),
                                      rs.getInt("quantidade"),
                                      rs.getInt("armazem_codigo"),
                                      rs.getInt("fornecedor_cnpj")));
        }
        while(rs.next());
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return arrayProduto;
  }
}