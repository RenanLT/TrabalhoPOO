package controller;

import java.util.*; // Em fun��o da classe ArrayList
import java.sql.*;

public class CtrlPagamento
{   
  public CtrlPagamento(int int1, double double1, String string, String string2, String string3, String string4,
			String string5) {
		// TODO Auto-generated constructor stub
	}

public static int inclui (Connection conn, int codigo, double valor, String data, String nome, String descricao, String situacao, int pedido_codigo) 
    throws SQLException
  {   
    PreparedStatement pstmt = conn.prepareStatement
      ("select Pagamento_seq.nextval as contador from sys.dual");
    ResultSet rs = pstmt.executeQuery();
    rs.next();
    int pk = rs.getInt("contador");
    rs.close();
    pstmt.close();
    
    pstmt = conn.prepareStatement
      ("insert into Pagamento(codigo, valor, data, nome, descricao, situacao, pedido_codigo) " +
       "values(?, ?, ?, ?, ?, ?, ?)");
    pstmt.setInt(1, codigo);
    pstmt.setDouble(2, valor);
    pstmt.setString(3, data);
    pstmt.setString(4, nome);
    pstmt.setString(4, descricao);
    pstmt.setString(4, situacao);
    pstmt.setInt(4, pedido_codigo);
    
    pstmt.executeUpdate();
    pstmt.close();
    
    return pk;
  }

  public static boolean altera(Connection conn, int codigo, double valor, String data, String nome, String descricao, String situacao, int pedido_codigo) 
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("update Pagamento set valor = ?, data = ? ,nome = ?, descricao = ?, situacao = ? where codigo = ?");
    pstmt.setDouble(1, valor);
    pstmt.setString(2, data);
    pstmt.setString(3, nome);
    pstmt.setString(3, descricao);
    pstmt.setString(3, situacao);
    pstmt.setInt(4, codigo);
    
    int n = pstmt.executeUpdate();

    pstmt.close();
    
    return n == 1;
  }


  public static boolean exclui (Connection conn, int codigo) 
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("delete from Pagamento where codigo = ?");
    pstmt.setInt(1, codigo);
    
    int n = pstmt.executeUpdate();
    
    pstmt.close();
    
    return n == 1;
  }

  public static CtrlPagamento recuperaUmPagamento(Connection conn, int codigo)
  { CtrlPagamento umPagamento = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Pagamento where codigo = ?");
      pstmt.setInt(1, codigo);
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { umPagamento = new CtrlPagamento(rs.getInt("codigo"),
                                  rs.getDouble("valor"),
                                  rs.getString("data"),
                                  rs.getString("nome"),
                                  rs.getString("descricao"),
                                  rs.getString("situacao"),
                                  rs.getString("pedido_codigo"));
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return umPagamento;
  }

  public static ArrayList<CtrlPagamento> recuperaPagamento(Connection conn)
  { ArrayList<CtrlPagamento> arrayPagamento = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Pagamento");
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { arrayPagamento = new ArrayList<CtrlPagamento>(20);
        do
        { arrayPagamento.add(new CtrlPagamento(rs.getInt("codigo"),
                                  rs.getDouble("valor"),
                                  rs.getString("data"),
                                  rs.getString("nome"),
                                  rs.getString("descricao"),
                                  rs.getString("situacao"),
                                  rs.getString("pedido_codigo")));
        }
        while(rs.next());
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return arrayPagamento;
  }
}

