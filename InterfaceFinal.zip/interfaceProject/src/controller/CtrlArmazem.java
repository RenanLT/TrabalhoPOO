package controller;

import java.util.*; // Em fun��o da classe ArrayList
import java.sql.*;

public class CtrlArmazem
{   
  public CtrlArmazem(int int1, String string, String string2, String string3) {
		// TODO Auto-generated constructor stub
	}

public static int inclui (Connection conn, int codigo, String nome, String endereco, String descricao) 
    throws SQLException
  {   
    PreparedStatement pstmt = conn.prepareStatement
      ("select Armazem_seq.nextval as contador from sys.dual");
    ResultSet rs = pstmt.executeQuery();
    rs.next();
    int pk = rs.getInt("contador");
    rs.close();
    pstmt.close();
    
    pstmt = conn.prepareStatement
      ("insert into Armazem(codigo, nome, endereco, descricao) " +
       "values(?, ?, ?, ?)");
    pstmt.setInt(1, codigo);
    pstmt.setString(2, nome);
    pstmt.setString(3, endereco);
    pstmt.setString(4, descricao);
    
    pstmt.executeUpdate();
    pstmt.close();
    
    return pk;
  }

  public static boolean altera(Connection conn, int codigo, String nome, String endereco, String descricao) 
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("update Armazem set nome = ?, endereco = ? ,descricao = ? where codigo = ?");
    pstmt.setString(1, nome);
    pstmt.setString(2, endereco);
    pstmt.setString(3, descricao);
    pstmt.setInt(4, codigo);
    
    int n = pstmt.executeUpdate();

    pstmt.close();
    
    return n == 1;
  }


  public static boolean exclui (Connection conn, int codigo) 
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("delete from Armazem where codigo = ?");
    pstmt.setInt(1, codigo);
    
    int n = pstmt.executeUpdate();
    
    pstmt.close();
    
    return n == 1;
  }

  public static CtrlArmazem recuperaUmArmazem(Connection conn, int codigo)
  { CtrlArmazem umArmazem = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Armazem where codigo = ?");
      pstmt.setInt(1, codigo);
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { umArmazem = new CtrlArmazem(rs.getInt("codigo"),
                                  rs.getString("nome"),
                                  rs.getString("endereco"),
                                  rs.getString("descricao"));
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return umArmazem;
  }

  public static ArrayList<CtrlArmazem> recuperaArmazem(Connection conn)
  { ArrayList<CtrlArmazem> arrayArmazem = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Armazem");
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { arrayArmazem = new ArrayList<CtrlArmazem>(20);
        do
        { arrayArmazem.add(new CtrlArmazem(rs.getInt("codigo"),
                                  rs.getString("nome"),
                                  rs.getString("endereco"),
                                  rs.getString("descricao")));
        }
        while(rs.next());
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return arrayArmazem;
  }
}