package controller;

import java.util.*; // Em fun��o da classe ArrayList
import java.sql.*;

public class CtrlCliente_Fisico
{   
  public CtrlCliente_Fisico(int int1, String string, String string2) {
		// TODO Auto-generated constructor stub
	}

public static int inclui (Connection conn, int cpf, String sexo, String data_nascimento) 
    throws SQLException
  {   
    PreparedStatement pstmt = conn.prepareStatement
      ("select Cliente_Fisico_seq.nextval as contador from sys.dual");
    ResultSet rs = pstmt.executeQuery();
    rs.next();
    int pk = rs.getInt("contador");
    rs.close();
    pstmt.close();
    
    pstmt = conn.prepareStatement
      ("insert into Cliente_Fisico(cpf, sexo, data_nascimento) values(?, ?, ?)");
    pstmt.setInt(1, cpf);
    pstmt.setString(2, sexo);
    pstmt.setString(3, data_nascimento);
    
   
    
    pstmt.executeUpdate();
    pstmt.close();
    
    return pk;
  }

  public static boolean altera(Connection conn, int cpf, String sexo, String data_nascimento) 
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("update Cliente_Fisico set sexo = ?, data_nascimento = ? where cpf = ?");
    pstmt.setInt(1, cpf);
    pstmt.setString(2, sexo);
    pstmt.setString(3, data_nascimento);
    
    
    int n = pstmt.executeUpdate();

    pstmt.close();
    
    return n == 1;
  }


  public static boolean exclui (Connection conn, String cpf) 
    throws SQLException
  { PreparedStatement pstmt = conn.prepareStatement
      ("delete from Cliente_Fisico where cpf = ?");
    pstmt.setString(1, cpf);
    
    int n = pstmt.executeUpdate();
    
    pstmt.close();
    
    return n == 1;
  }

  public static CtrlCliente_Fisico recuperaUmCliente_Fisico(Connection conn, int cpf, String sexo, String data_nascimento)
  { CtrlCliente_Fisico umCliente_Fisico = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Cliente_Fisico where cpf = ?");
      pstmt.setInt(1, cpf);
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { umCliente_Fisico = new CtrlCliente_Fisico(rs.getInt("cpf"),
                                      rs.getString("sexo"),
                                      rs.getString("data_nascimento"));
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return umCliente_Fisico;
  }

  public static ArrayList<CtrlCliente_Fisico> recuperaCliente_Fisico(Connection conn)
  { ArrayList<CtrlCliente_Fisico> arrayCliente_Fisico = null;   
      
    try
    { PreparedStatement pstmt = conn.prepareStatement
        ("select * from Cliente_Fisico");
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      { arrayCliente_Fisico = new ArrayList<CtrlCliente_Fisico>(20);
        do
        { arrayCliente_Fisico.add(new CtrlCliente_Fisico(rs.getInt("cpf"),
                                      rs.getString("sexo"),
                                      rs.getString("data_nascimento")));
        }
        while(rs.next());
      }
      rs.close();
      pstmt.close();
    } 
    catch (SQLException e)
    { e.printStackTrace();
      System.exit(1);
    }

    return arrayCliente_Fisico;
  }
}
