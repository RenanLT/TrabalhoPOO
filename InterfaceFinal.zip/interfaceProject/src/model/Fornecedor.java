package model;

public class Fornecedor
{
  
 int cnpj;
  String razao_social;
  String nome;
  String contato;
  String endereco;
  String descricao;

  public Fornecedor (int cnpj, String razao_social, String nome, String contato, String endereco, String descricao)
  {
    this.cnpj = cnpj;
    this.razao_social = razao_social;
    this.nome = nome;
    this.contato = contato;
    this.endereco =endereco;
    this.descricao = descricao;
    
  }
}
