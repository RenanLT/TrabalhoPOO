package model;

public class Cliente 
{
  
  int matricula;
  String nome;
  String contato;
  String endereco;
  String situacao;

  public Cliente (int matricula, String nome, String contato, String endereco, String situacao)
  {
    this.matricula = matricula;
    this.nome = nome;
    this.contato = contato;
    this.endereco = endereco;
    this.situacao =situacao;
  }
}

