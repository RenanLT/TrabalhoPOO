package model;

public class Cliente_Fisico extends Cliente
{
   int cpf;
   String sexo;
   String data_nascimento;

  public Cliente_Fisico (int matricula, String nome, String contato, String endereco, String situacao, int cpf, String sexo, String data_nascimento)
  {
    super(matricula, nome, contato, endereco, situacao);
    this.cpf = cpf;
    this.sexo = sexo;
    this.data_nascimento = data_nascimento;
  }
} 
