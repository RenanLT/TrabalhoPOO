package model;

public class Pedido {
	  int codigo;
	  String data;
	  double valor;
	  String situacao;
	  int cliente_matricula;

	  public Pedido( int codigo, String data, double valor, String situacao,  int cliente_matricula)
	  {
	    this.codigo = codigo;
	    this.data = data;
	    this.valor = valor;
	    this.situacao = situacao;
	    this.cliente_matricula = cliente_matricula;

	  }

}
